package net.codejava.ws.axis2;

/**
 * A simple POJO class.
 * @author www.codejava.net
 */
public class CalculatorService {

	public int sum(int x, int y) {
		return (x + y);
	}
}